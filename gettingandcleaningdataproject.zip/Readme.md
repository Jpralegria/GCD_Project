The purpose of this project is to provide directions to manipulated sensor data. If you've been involved before with this kind of data, you may know that software engineers follow customer requirements and most of the times what customer could pay. Data is limited by hardware capability also, hence what it seems easy to get done in MS software it's complicate when customer want cheap solutions. 

This time data set comes from the accelerometer and gyroscope 3-axial raw signals tAcc-XYZ and tGyro-XYZ, this hardware is part of Samsung Galaxy S smartphone. Accelerometer readings follow a 50Hz constant rate, smoothed with a corner frequency of 20 Hz to remove noise. 

